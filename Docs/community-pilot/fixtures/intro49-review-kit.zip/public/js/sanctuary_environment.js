/* Circle D Flow — original procedural Sanctuary, Three.js r128.
 * Reference: https://archive.artic.edu/benin/palace/ (courtyards, wood, brass).
 * Earthen architecture reference: British Museum MOWAA Benin City report (2025).
 * Hut roofs, spirit imagery and geometric motifs are independent fantasy design.
 * Geometry only: no accounts, rewards, fictional visitors, media fetches or loop.
 * Load sanctuary_layout.js first. Root owns camera, neutral lighting and renderer.
 */
(function(root){
  'use strict';
  function build(T,scene,options={}){
    const layout=root.CDFSanctuaryLayout;
    if(!layout||!T?.Group||!scene?.add)throw Error('Sanctuary layout and Three.js are required.');
    const mobile=Boolean(options.mobile),reducedMotion=Boolean(options.reducedMotion);
    const language=['en','pt','de'].includes(options.language)?options.language:'en';
    const group=new T.Group();group.name='CDF Sanctuary · spirit kingdom';
    const geometries=new Map(),materials=new Map(),textures=new Set(),lights=[],sway=[];
    let disposed=false;
    const palette={stone:0xb8794b,mortar:0x713c30,cream:0xdca979,white:0xf3dfac,ink:0x302235,metal:0x8c603e,wood:0x503126,terracotta:0xa6553f,blue:0x506c86,gold:0xe2b965,green:0x42695b,velvet:0x6d4356};
    if(root.CDFLisbonContext?.theme==='river')Object.assign(palette,{blue:0x527987,green:0x5b7964});
    if(root.CDFLisbonContext?.theme==='garden')Object.assign(palette,{stone:0xa18758,green:0x638754,velvet:0x586649});
    function geometry(type,args,binding='regular'){const key=binding+':'+type+JSON.stringify(args);if(!geometries.has(key))geometries.set(key,new T[type](...args));return geometries.get(key);}
    // Palette values are authored in sRGB; r128 StandardMaterial expects linear light.
    // CanvasTexture maps already declare sRGBEncoding and must not be decoded twice.
    const cssColor=value=>typeof value==='number'?'#'+value.toString(16).padStart(6,'0'):value;
    function material(name,color,extra={}){
      if(!materials.has(name)){const parameters={color:cssColor(color),...extra};delete parameters.roughness;delete parameters.metalness;if(parameters.emissive!==undefined)parameters.emissive=cssColor(parameters.emissive);const value=new T.MeshToonMaterial(parameters);value.color.convertSRGBToLinear();value.name=name;materials.set(name,value);}
      return materials.get(name);
    }
    const stone=material('stone',palette.stone),cream=material('cream',palette.cream),ink=material('ink',palette.ink),wood=material('wood',palette.wood),metal=material('metal',palette.metal,{metalness:.55,roughness:.45}),gold=material('gold',palette.gold,{metalness:.35,roughness:.45}),tile=material('tile',palette.white,{roughness:.5}),terracotta=material('terracotta',palette.terracotta),green=material('green',palette.green),seat=material('seat',palette.velvet);
    const lightMaterial=material('warm glass',0xffe8ba,{emissive:0xffd398,emissiveIntensity:.55,roughness:.4});
    const cyan=material('cinema accent',0x92cdd7,{emissive:0x407b8c,emissiveIntensity:.25});
    const purple=material('stage accent',0xb6a0ed,{emissive:0x635185,emissiveIntensity:.25});
    const matrixObject=new T.Object3D();
    function mesh(type,args,mat,parent=group){const object=new T.Mesh(geometry(type,args),mat);parent.add(object);object.castShadow=!mobile;object.receiveShadow=!mobile;return object;}
    function box(w,h,d,x,y,z,mat,parent=group){const object=mesh('BoxGeometry',[1,1,1],mat,parent);object.scale.set(w,h,d);object.position.set(x,y,z);return object;}
    function cylinder(top,bottom,height,x,y,z,mat,parent=group,segments=mobile?8:12){const object=mesh('CylinderGeometry',[top,bottom,height,segments],mat,parent);object.position.set(x,y,z);return object;}
    function sphere(radius,x,y,z,mat,parent=group){const object=mesh('SphereGeometry',[radius,mobile?8:12,mobile?6:8],mat,parent);object.position.set(x,y,z);return object;}
    function bar(from,to,radius,mat,parent=group){const a=new T.Vector3(...from),b=new T.Vector3(...to),distance=a.distanceTo(b);const object=cylinder(radius,radius,distance,0,0,0,mat,parent,6);object.position.copy(a).add(b).multiplyScalar(.5);object.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),b.sub(a).normalize());return object;}
    function repeated(type,args,mat,placements,parent=group){
      const object=new T.InstancedMesh(geometry(type,args,'instances-'+group.children.length+'-'+parent.children.length),mat,placements.length);parent.add(object);object.castShadow=false;object.receiveShadow=!mobile;
      placements.forEach((value,index)=>{matrixObject.position.set(value.x||0,value.y||0,value.z||0);matrixObject.rotation.set(value.rx||0,value.ry||0,value.rz||0);matrixObject.scale.set(value.sx||1,value.sy||1,value.sz||1);matrixObject.updateMatrix();object.setMatrixAt(index,matrixObject.matrix);if(value.color!==undefined)object.setColorAt(index,new T.Color(cssColor(value.color)).convertSRGBToLinear());});
      object.instanceMatrix.needsUpdate=true;if(object.instanceColor)object.instanceColor.needsUpdate=true;return object;
    }
    function canvasTexture(paint,width=mobile?512:1024,height=mobile?128:256){
      if(!root.document?.createElement)return null;
      const canvas=root.document.createElement('canvas');canvas.width=width;canvas.height=height;
      const context=canvas.getContext('2d');if(!context)return null;paint(context,width,height);
      const texture=new T.CanvasTexture(canvas);texture.encoding=T.sRGBEncoding;texture.anisotropy=mobile?1:4;textures.add(texture);return texture;
    }
    function sign(text,x,y,z,rotation,width=7,height=1,color='#e2c891'){
      const texture=canvasTexture((ctx,w,h)=>{ctx.fillStyle='#182832';ctx.fillRect(0,0,w,h);ctx.strokeStyle=color;ctx.lineWidth=4;ctx.strokeRect(8,8,w-16,h-16);ctx.fillStyle=color;ctx.textAlign='center';ctx.textBaseline='middle';let size=Math.floor(h*.45);ctx.font='600 '+size+'px sans-serif';while(ctx.measureText(text).width>w*.87&&size>10){size--;ctx.font='600 '+size+'px sans-serif';}ctx.fillText(text,w/2,h/2);});
      const mat=texture?new T.MeshBasicMaterial({map:texture,side:T.DoubleSide}):material('sign fallback '+color,color);
      if(texture)materials.set('sign '+materials.size,mat);
      const object=mesh('PlaneGeometry',[width,height],mat);object.position.set(x,y,z);object.rotation.y=rotation;object.castShadow=false;return object;
    }
    function label(id,x,y,z,rotation,width=7){const zone=layout.zones.find(zone=>zone.id===id);const arrivalFacing=Math.atan2(-x,28-z);return sign(zone.labels[language],x,y,z,arrivalFacing,width,1.05,zone.color);}
    // A fantasy interpretation of Edo/Benin courtyard materials, not a reconstruction.
    // All motifs below are original geometry: no copied royal/sacred objects or insignia.
    const earth=material('red earth',0x8c513d);
    const sand=material('worn earth paths',0xb78053);
    const reed=material('woven roof',0x8d6841);
    const reedLight=material('woven roof edge',0xbe9458);
    box(57,.35,61,0,-.23,-4,earth);
    const soil=[];
    for(let z=-30;z<24;z+=2.8)for(let x=-25;x<26;x+=2.8){
      soil.push({x:x+Math.sin(z+x)*.18,y:-.015,z,sx:1.1+Math.abs(Math.sin(x))*1.3,sy:.035,sz:1.5,color:(Math.round(x+z)%3)?0x91553e:0x9c6044});
    }
    repeated('CylinderGeometry',[1,1,1,6],material('earth patches',0xffffff),soil);
    box(4.8,.035,50,0,.025,-3,sand);
    [-6,12].forEach(z=>box(28,.035,3.2,0,.029,z,sand));
    const edging=[];
    for(let z=-28;z<23;z+=1.8)for(const x of [-2.65,2.65])edging.push({x,y:.065,z,sx:.18,sy:.12,sz:.75});
    repeated('SphereGeometry',[1,6,4],stone,edging);
    [2.8,3.25].forEach(radius=>{const ring=mesh('TorusGeometry',[radius,.035,5,48],gold);ring.rotation.x=Math.PI/2;ring.position.set(0,.08,1);ring.castShadow=false;});
    for(let i=0;i<8;i++){const angle=i*Math.PI/4;const gem=mesh('OctahedronGeometry',[.13,0],cyan);gem.position.set(Math.sin(angle)*3.25,.13,1+Math.cos(angle)*3.25);}

    function column(x,z,height=4.6){
      cylinder(.2,.26,height,x,height/2,z,wood);
      (mobile?[.4,height-.45]:[.4,height*.45,height-.45]).forEach(y=>cylinder(.235,.235,.13,x,y,z,gold));
      box(.42,height*.55,.08,x,height*.52,z+.2,material('brass pillar panel',0xa77a43));
      for(let i=0;i<(mobile?1:3);i++){const ring=mesh('TorusGeometry',[.11,.024,4,12],gold);ring.position.set(x,height*.34+i*.38,z+.25);}
    }
    function hipRoof(x,z,width,depth,eave,height){
      const roof=mesh('ConeGeometry',[1,1,4],reed);roof.rotation.y=Math.PI/4;roof.scale.set(width/Math.SQRT2,height,depth/Math.SQRT2);roof.position.set(x,eave+height/2,z);
      box(width,.16,depth,x,eave,z,reedLight);
      for(const side of [-1,1])for(const edge of [-1,1])bar([x+side*width*.5,eave,z+edge*depth*.5],[x,eave+height,z],.055,reedLight);
      // Layered eaves suggest woven fibres without thousands of individual strands.
      for(let i=1;i<=(mobile?1:3);i++){const t=i/5;const trim=mesh('CylinderGeometry',[1-t-.035,1-t,.11,4],reedLight);trim.rotation.y=Math.PI/4;trim.scale.set(width/Math.SQRT2,1,depth/Math.SQRT2);trim.position.set(x,eave+t*height,z);}
      const finial=mesh('OctahedronGeometry',[.25,0],gold);finial.position.set(x,eave+height+.2,z);
    }
    // Enclosing earthen walls and a broad entrance leave the playable routes clear.
    box(.65,1.35,58,-26.7,.65,-4,terracotta);box(.65,1.35,58,26.7,.65,-4,terracotta);
    box(54,2.1,.65,0,1,-32.8,terracotta);
    [-15,15].forEach(x=>box(22,1.35,.65,x,.65,24.8,terracotta));
    [-4.2,4.2].forEach(x=>column(x,25.4,5.2));
    // Open gateway: a crossbeam here cuts through the initial follow-camera view.
    [-18,18].forEach(x=>{
      box(14,5.5,2,x,2.75,-31,terracotta);
      hipRoof(x,-31,15,4,5.5,2.5);
      [-4.5,0,4.5].forEach(offset=>{box(1.3,3,.09,x+offset,1.55,-29.94,ink);box(1.6,.16,.15,x+offset,3.1,-29.85,gold);});
    });

    // Royal music pavilion: timber, earthen enclosure and hand-crafted instruments.
    box(16.8,.2,8.8,0,.1,-24.1,wood);
    box(16.8,5.1,.5,0,2.8,-28.7,terracotta);
    [-7.8,7.8].forEach(x=>{column(x,-20.2,6.3);column(x,-28.4,6.3);});
    hipRoof(0,-24.3,18.2,10.3,6.3,3.5);
    label('stage',0,4.9,-28.4,0,11.8);
    sign('BANTABA / SOUND & SOUL',0,3.7,-28.39,0,8,.6,'#f2d49d');
    [-6.8,6.8].forEach(x=>{box(.85,1.8,.75,x,1.15,-26.7,wood);const disk=mesh('TorusGeometry',[.27,.06,5,16],gold);disk.position.set(x,1.2,-26.28);});
    [[0,-25.8,.8],[-1,-26.4,.45],[1,-26.4,.45],[2.8,-26.6,.4],[3.65,-26.6,.4]].forEach(([x,z,r])=>{cylinder(r,r*.6,1.25,x,.9,z,wood);cylinder(r,r,.07,x,1.56,z,cream);});
    // A fantasy wooden keyed instrument occupies the previous keyboard footprint.
    box(3.1,.18,.92,-5,1.45,-25.1,wood);
    [-6,-4].forEach(x=>bar([x,.2,-25.1],[x,1.4,-25.1],.09,wood));
    for(let i=0;i<12;i++)box(.17,.07,.8-i*.025,-6.35+i*.24,1.59,-25.1,reedLight);
    const harp=new T.Group();harp.position.set(4.7,.28,-25);group.add(harp);
    bar([-.65,0,0],[-.65,3.1,0],.1,wood,harp);bar([-.65,3.1,0],[.65,.3,0],.1,gold,harp);bar([-.65,.3,0],[.65,.3,0],.1,wood,harp);
    for(let i=0;i<6;i++)bar([-.5+i*.17,.32,.03],[-.5+i*.17,2.85-i*.36,.03],.012,gold,harp);
    column(2.5,-21.4,2.5);sphere(.23,2.5,2.8,-21.4,lightMaterial);

    // Kitchen hut: red clay walls and an open, timber-framed service porch.
    box(.6,4.5,12,-23.7,2.25,-6,terracotta);
    [-11.75,-.25].forEach(z=>box(10,4.5,.5,-19,2.25,z,terracotta));
    [-11.5,-.5].forEach(z=>column(-13.9,z,4.5));
    hipRoof(-19,-6,11.8,14,4.6,3.3);
    label('kitchen',-13.7,3.9,-6,Math.PI/2,8.5);
    box(1.6,1.1,8,-15.2,.6,-6,terracotta);box(1.85,.15,8.3,-15.2,1.23,-6,wood);
    [-9,-6,-3].forEach(z=>{cylinder(.29,.22,.5,-15.2,1.57,z,terracotta);sphere(.19,-15.2,1.88,z,green);});
    cylinder(.55,.7,.5,-22.7,.35,-8,stone);cylinder(.35,.45,.65,-22.7,.92,-8,ink);
    for(let i=0;i<7;i++){const pattern=mesh('TorusGeometry',[.19,.035,4,16],gold);pattern.rotation.y=Math.PI/2;pattern.position.set(-23.35,2.9,-10+i*1.3);}

    // Open-air story pavilion: original illustrated screen, no invented film playback.
    box(11.2,.06,14.6,18.7,.025,-7,earth);
    box(.65,6.2,12.8,23.8,3.15,-7,terracotta);
    const poster=canvasTexture((ctx,w,h)=>{
      const sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,'#302544');sky.addColorStop(1,'#aa6c53');ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
      ctx.fillStyle='#f0d198';ctx.beginPath();ctx.arc(w*.7,h*.28,h*.14,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#543a47';ctx.beginPath();ctx.moveTo(0,h);for(let i=0;i<10;i++)ctx.lineTo(i*w/9,h*(.6+(i%3)*.08));ctx.lineTo(w,h);ctx.fill();
      ctx.fillStyle='#f6e3bc';ctx.textAlign='center';ctx.font='600 '+Math.floor(h*.14)+'px serif';ctx.fillText('VISION',w*.43,h*.4);
      ctx.font=Math.floor(h*.055)+'px sans-serif';ctx.fillText(language==='de'?'GESCHICHTEN UNTER STERNEN':language==='pt'?'HISTÓRIAS SOB AS ESTRELAS':'STORIES UNDER THE STARS',w*.43,h*.54);
    },mobile?512:1024,mobile?256:512);
    const screenMaterial=poster?new T.MeshBasicMaterial({map:poster,side:T.DoubleSide}):cream;if(poster)materials.set('cinema screen',screenMaterial);
    const screen=mesh('PlaneGeometry',[11.5,5.35],screenMaterial);screen.rotation.y=-Math.PI/2;screen.position.set(23.46,3.2,-7);screen.castShadow=false;
    [-13.1,-.9].forEach(z=>{column(23.35,z,6.4);bar([13.5,4.9,z],[23.5,6.1,z],.1,wood);});
    label('cinema',12.8,4.45,-7,-Math.PI/2,9.6);
    const seats=[],backs=[],legs=[];
    [15.2,17.5,19.8,22.1].forEach(x=>[-11,-8.3,-5.6,-2.9].forEach(z=>{
      seats.push({x,y:.68,z,sx:1.05,sy:.18,sz:1.5});backs.push({x:x-.52,y:1.12,z,sx:.16,sy:.9,sz:1.5});
      [-.48,.48].forEach(offset=>legs.push({x,y:.3,z:z+offset,sx:.09,sy:.55,sz:.09}));
    }));
    repeated('BoxGeometry',[1,1,1],wood,seats);repeated('BoxGeometry',[1,1,1],seat,backs);repeated('BoxGeometry',[1,1,1],wood,legs);

    // Guild and creator huts retain their accessible entrances and collision footprints.
    box(.6,4.4,12,-23.7,2.2,15,terracotta);
    [-14.5,-23.3].forEach(x=>column(x,20.5,4.6));hipRoof(-19,15,11.8,14,4.6,3.4);
    cylinder(1.9,1.9,.16,-19.5,1.24,15,wood);cylinder(.16,.2,1.2,-19.5,.6,15,wood);
    [[-19.5,12.3],[-19.5,17.7],[-22.1,15]].forEach(([x,z])=>{cylinder(.43,.43,.13,x,.75,z,reedLight);cylinder(.12,.16,.7,x,.35,z,wood);});
    label('guild',-14.1,3.9,15,Math.PI/2,8.5);
    sign(language==='de'?'DEIN KREIS':language==='pt'?'O TEU CÍRCULO':'YOUR CIRCLE',-23.34,2.7,15,Math.PI/2,7.8,1.4,'#e3c68e');
    box(.6,4.4,12,23.7,2.2,15,terracotta);hipRoof(19.2,15,11.8,14,4.6,3.4);
    label('atelier',14.2,3.9,15,-Math.PI/2,9.8);
    box(5,.16,2.8,20,1.25,18.8,wood);[-2,2].forEach(offset=>box(.15,1.2,2.4,20+offset,.6,18.8,wood));
    [11,14.5].forEach((z,index)=>{
      bar([19.3,0,z-.8],[20.4,3.2,z],.055,wood);bar([19.3,0,z+.8],[20.4,3.2,z],.055,wood);bar([21.3,0,z],[20.4,3.2,z],.055,wood);
      const art=canvasTexture((ctx,w,h)=>{ctx.fillStyle=index?'#56384d':'#273f51';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#e9c17b';ctx.lineWidth=h*.025;ctx.beginPath();for(let i=0;i<150;i++){const a=i*.12,r=i*h*.0018;const x=w*.5+Math.cos(a)*r,y=h*.5+Math.sin(a)*r;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();},128,128);
      const mat=art?new T.MeshBasicMaterial({map:art,side:T.DoubleSide}):cream;if(art)materials.set('original art '+index,mat);
      const canvas=mesh('PlaneGeometry',[1.6,2],mat);canvas.rotation.y=-Math.PI/2;canvas.position.set(19.5,2.1,z);canvas.castShadow=false;
    });

    // Timber lanterns and broad-leaf fantasy trees soften the courtyard boundary.
    [[-10,-17],[10,-17],[-11,21],[11,21]].forEach(([x,z],index)=>{
      cylinder(.12,.2,3.5,x,1.75,z,wood);bar([x,3.4,z],[x+.6,3.4,z],.09,wood);
      const lantern=mesh('OctahedronGeometry',[.3,0],lightMaterial);lantern.position.set(x+.6,3,z);cylinder(.34,.18,.18,x+.6,2.68,z,gold);
      if(index<(mobile?1:2)){const light=new T.PointLight(0xffd28f,.55,14,2);light.position.set(x+.6,3,z);group.add(light);lights.push(light);}
    });
    [-28.7,28.7].forEach(x=>[-22,-1,20].forEach(z=>{
      cylinder(.38,.6,5.8,x,2.7,z,wood);
      [-1,1].forEach(side=>bar([x,3.9,z],[x+side*1.5,6,z+.3],.22,wood));
      const crown=sphere(2.6,x,6.2,z,green);crown.scale.y=.58;
      if(!mobile){sphere(1.55,x-1.7,5.8,z+.2,green);sphere(1.7,x+1.7,6,z,green);}
    }));
    // A few luminous spirit seeds are decorative, never other users or rewards.
    [-8,8].forEach((x,index)=>{const seed=sphere(.16,x,4.7,-20.3,index?cyan:purple);sway.push(seed);});
    // Optional learning markers: original sketches, not sacred/royal Edo ornaments.
    if(root.CDFEweLibrary){
      const library=root.CDFEweLibrary;
      layout.zones.forEach(zone=>{
        const symbol=library.forZone(zone.id),x=zone.approach.x+(zone.approach.x===0?3.5:Math.sign(zone.approach.x)*2),z=zone.approach.z;
        const texture=canvasTexture((ctx,w,h)=>{ctx.fillStyle='#302436';ctx.fillRect(0,0,w,h);library.draw(ctx,symbol.visual,w,h);},256,256);
        if(!texture)return;
        const mat=new T.MeshBasicMaterial({map:texture,side:T.DoubleSide});materials.set('learning '+zone.id,mat);
        const plaque=mesh('PlaneGeometry',[.85,.85],mat);plaque.position.set(x,2.15,z);plaque.rotation.y=Math.atan2(-x,28-z);plaque.castShadow=false;
        // Floating marker has no solid post to create an unmodelled collision.
        sign(symbol.name,x,1.56,z,plaque.rotation.y,1.7,.32,'#edcc89');
      });
    }
    scene.add(group);
    const stats={meshes:0,instancedMeshes:0,instances:0,triangles:0,geometries:geometries.size,materials:materials.size,textures:textures.size,lights:lights.length};
    group.traverse(object=>{if(!object.isMesh)return;stats.meshes++;const count=object.isInstancedMesh?object.count:1;if(object.isInstancedMesh){stats.instancedMeshes++;stats.instances+=count;}stats.triangles+=(object.geometry.index?object.geometry.index.count:object.geometry.attributes.position.count)/3*count;});
    function update(time){if(disposed||reducedMotion||!Number.isFinite(time))return;sway.forEach((seed,index)=>{seed.position.y=4.7+Math.sin(time*.8+index)*.18;});}
    function dispose(){if(disposed)return;disposed=true;scene.remove(group);textures.forEach(texture=>texture.dispose());materials.forEach(mat=>mat.dispose());geometries.forEach(geo=>geo.dispose());}
    return {group,zones:layout.zones,obstacles:layout.obstacles,bounds:layout.bounds,spawn:layout.spawn,stats:Object.freeze(stats),update,dispose};
  }
  const api=Object.freeze({build});root.CDFSanctuaryEnvironment=api;
  if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window==='undefined'?globalThis:window);

