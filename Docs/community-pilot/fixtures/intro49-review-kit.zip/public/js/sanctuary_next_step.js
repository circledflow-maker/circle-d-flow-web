/* Optional first-step navigation. URL hints never verify an account or grant rewards. */
(function () {
 'use strict';
 const guide=document.getElementById('flowee-guide');
 const entry=document.getElementById('welcome-wayfinder');
 if(!guide||!entry)return;
 const copy={
  en:{entry:'✦ Ask Flowee: where do I begin?',dismiss:'Hide arrival hint',title:'Choose one small next step',note:'Choose freely. Exploring grants no points; each destination checks its own access.',actions:[['My Wako Kungo card','Find your card and verified progress with the same CDF account.'],['Explore real Lisbon','Open the Atlas. Location stays off until you choose to share it.'],['Create something','Open Vision Studio; keep drafts private until you choose to share.']]},
  de:{entry:'✦ Flowee fragen: Wo beginne ich?',dismiss:'Ankunftshinweis ausblenden',title:'Wähle einen kleinen nächsten Schritt',note:'Du entscheidest frei. Erkunden vergibt keine Punkte; Zugänge werden am Ziel geprüft.',actions:[['Meine Wako-Kungo-Karte','Karte und bestätigten Fortschritt mit demselben CDF-Konto wiederfinden.'],['Das echte Lissabon erkunden','Den Atlas öffnen. Standortfreigabe bleibt deine bewusste Entscheidung.'],['Etwas gestalten','Vision Studio öffnen und Entwürfe bis zu deiner Freigabe privat halten.']]},
  pt:{entry:'✦ Perguntar à Flowee: por onde começo?',dismiss:'Ocultar sugestão de chegada',title:'Escolhe um pequeno próximo passo',note:'A escolha é tua. Explorar não dá pontos; cada destino verifica o acesso.',actions:[['O meu cartão Wako Kungo','Encontra o cartão e o progresso confirmado com a mesma conta CDF.'],['Explorar Lisboa real','Abre o Atlas. A localização só é partilhada se tu escolheres.'],['Criar algo','Abre o Vision Studio e mantém os rascunhos privados até decidires partilhar.']]}
 };
 const section=document.createElement('section');section.className='wayfinder-choices';
 const heading=document.createElement('h3');heading.id='wayfinder-title';section.setAttribute('aria-labelledby',heading.id);
 const nav=document.createElement('nav');nav.setAttribute('aria-labelledby',heading.id);
 const routes=['/member-card?intro=skip','/pages/lisbon_world.html','/pages/vision_studio.html'];
 const links=routes.map(route=>{const link=document.createElement('a');link.href=route;const title=document.createElement('strong'),description=document.createElement('span');link.append(title,description);nav.append(link);return {title,description};});
 const note=document.createElement('p');note.className='small-note';section.append(heading,nav,note);
 guide.insertBefore(section,document.getElementById('guide-journey'));
 const open=entry.querySelector('button'),dismiss=entry.querySelector('[data-dismiss]');
 // The existing native dialog owns focus, Escape, background modality and replay.
 open.addEventListener('click',()=>document.getElementById('scene-guide').click());
 dismiss.addEventListener('click',()=>{entry.hidden=true;try{sessionStorage.setItem('cdf_sanctuary_hint_v1','dismissed');}catch(_){}document.getElementById('scene-guide').focus();});
 function render(){const t=copy[document.documentElement.lang]||copy.en;open.textContent=t.entry;dismiss.textContent='×';dismiss.setAttribute('aria-label',t.dismiss);heading.textContent=t.title;note.textContent=t.note;links.forEach((link,i)=>{link.title.textContent=t.actions[i][0];link.description.textContent=t.actions[i][1];});}
 let arrived=false,dismissed=false;
 try{arrived=new URLSearchParams(location.search).get('welcome')==='register';}catch(_){}
 try{dismissed=sessionStorage.getItem('cdf_sanctuary_hint_v1')==='dismissed';}catch(_){}
 entry.hidden=!arrived||dismissed;
 render();
 new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

