/* Brief educational index; paraphrases NCC, 8 May 2025, checked 20 Oct 2026.
 * Drawings are ORIGINAL schematic learning illustrations, not authoritative glyph tracings.
 * Original images remain on the cited source. No licence for its photographs is asserted.
 */
(function(root){'use strict';
 const source='https://ghanaculture.gov.gh/indigenous-ewe-symbols-and-their-meaning/';
 const rows=[
 ['fiayi','Fiayi','Justice','Gerechtigkeit','Justiça'],['kavuvu','Kavuvu','Patience','Geduld','Paciência','vine'],
 ['zegbagba','Zegbagbã','Imperfection','Unvollkommenheit','Imperfeição','pot'],['nu-kple-ge','Nu Kple Ge','Sharing','Teilen','Partilha','sharing'],
 ['atamagui','Atamagui','Kindness','Güte','Bondade'],['gomekadi','Gomekaɖi','Light','Licht','Luz','lantern'],
 ['nku','ŋku kple alɔ̃','Review','Prüfen','Rever',null,true],['gui','Gui','Usefulness','Nützlichkeit','Utilidade','gourd'],
 ['koklozi','koklozi le kpe dzi','Caution','Vorsicht','Cautela'],['sabala','Sabala le nogo gake mɔ le eme','Coexistence','Koexistenz','Coexistência'],
 ['ahliha','Ahliha','Support','Unterstützung','Apoio','support'],['atokula','Atͻkula','Awakening','Erwachen','Despertar'],
 ['kpotimakpa','Kpͻtimakpa','Perseverance','Ausdauer','Perseverança'],['kokloxo','kokloxͻ','Contentment','Genügsamkeit','Contentamento'],
 ['ati','Ati alͻ etɔ̃','Worship','Verehrung','Culto'],['deti','Deti','Versatility','Vielseitigkeit','Versatilidade'],
 ['afoxodzo','Afͻxͻdzo','Punishment','Strafe','Punição'],['agaga','Agaga lolo','Value','Wert','Valor'],
 ['anyigba','anyigba sesẽ','Prudence','Umsicht','Prudência'],['lolosa','Lɔlɔ̃sakɔ','Review','Prüfen','Rever',null,true],
 ['da','Dã kuɖedzi','Review','Prüfen','Rever',null,true],['domenyo','Dɔmenyo tae’','Generosity','Großzügigkeit','Generosidade'],
 ['afia','Afia ɖe kpɔkpɔ','Diligence','Fleiß','Dedicação']
 ];
 const originals={kavuvu:'kavuvu.jpg',zegbagba:'djegbagba.jpg','nu-kple-ge':'nu-kple.jpg',gomekadi:'gomekaji.jpg',gui:'gui.jpg',ahliha:'alihla-1.jpg'};
 const symbols=rows.map(([id,name,en,de,pt,visual,review])=>Object.freeze({id,name,themes:Object.freeze({en,de,pt}),visual:visual||null,review:!!review,source,original:originals[id]?'https://ghanaculture.gov.gh/wp-content/uploads/2025/05/'+originals[id]:source}));
 const zones=Object.freeze({stage:'kavuvu',kitchen:'nu-kple-ge',cinema:'gomekadi',guild:'ahliha',atelier:'zegbagba',home:'gui'});
 // Generic object sketches: their identity/meaning must be read alongside the source.
 const sketches={
 vine:{lines:[[[50,86],[50,12]],[[50,31],[25,18]],[[50,48],[74,29]],[[50,65],[23,48]],[[50,80],[75,64]]],circles:[]},
 pot:{lines:[[[29,22],[71,22],[67,35],[79,52],[73,77],[60,87],[40,87],[26,77],[21,52],[33,35],[29,22]],[[51,23],[43,42],[57,55],[47,70],[54,86]]],circles:[]},
 sharing:{lines:[[[20,32],[35,43],[65,43],[80,32]],[[27,60],[50,83],[73,60]],[[39,57],[50,67],[61,57]]],circles:[[50,29,5]]},
 lantern:{lines:[[[35,25],[65,25],[73,77],[27,77],[35,25]],[[27,82],[73,82]],[[50,40],[50,65]],[[39,52],[61,52]]],circles:[[50,17,9]]},
 gourd:{lines:[[[43,15],[57,15],[55,38],[72,54],[76,70],[66,84],[34,84],[24,70],[28,54],[45,38],[43,15]]],circles:[]},
 support:{lines:[[[16,70],[24,41],[41,24],[72,31],[84,61],[72,70],[16,70]],[[20,83],[80,83]],[[30,76],[30,85]],[[70,76],[70,85]]],circles:[]}
 };
 function drawing(key){return sketches[key]||null;}
 function draw(ctx,key,w,h){const s=drawing(key);if(!s)return;const size=Math.min(w,h)*.88,ox=(w-size)/2,oy=(h-size)/2;ctx.strokeStyle='#edcc89';ctx.lineWidth=size*.035;ctx.lineCap='round';ctx.lineJoin='round';for(const points of s.lines){ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(ox+x/100*size,oy+y/100*size):ctx.moveTo(ox+x/100*size,oy+y/100*size));ctx.stroke();}for(const [x,y,r]of s.circles){ctx.beginPath();ctx.arc(ox+x/100*size,oy+y/100*size,r/100*size,0,Math.PI*2);ctx.stroke();}}
 const api=Object.freeze({source,checked:'2026-10-20',symbols:Object.freeze(symbols),zones,drawing,draw,forZone:zone=>symbols.find(s=>s.id===zones[zone])||symbols.find(s=>s.id==='gui')});root.CDFEweLibrary=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window==='undefined'?globalThis:window);
