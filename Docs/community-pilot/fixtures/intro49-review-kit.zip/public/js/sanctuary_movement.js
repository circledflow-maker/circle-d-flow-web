/* Local-only collision model. The visible scene and navigation share one layout. */
(function(root){'use strict';
function create(layout){
 const bounds=layout.bounds,spawn=layout.spawn,obstacles=layout.obstacles||[],circles=layout.circles||[];
 function walkable(x,z,radius=.45){return Number.isFinite(x)&&Number.isFinite(z)&&Number.isFinite(radius)&&radius>0&&x>=bounds.minX+radius&&x<=bounds.maxX-radius&&z>=bounds.minZ+radius&&z<=bounds.maxZ-radius&&!obstacles.some(o=>x>o.minX-radius&&x<o.maxX+radius&&z>o.minZ-radius&&z<o.maxZ+radius)&&!circles.some(o=>Math.hypot(x-o.x,z-o.z)<o.radius+radius);}
 function move(position,dx,dz,radius=.45){if(![position?.x,position?.z,dx,dz,radius].every(Number.isFinite)||radius<=0||!walkable(position.x,position.z,radius))return{x:spawn.x,z:spawn.z,blocked:true};let{x,z}=position;const distance=Math.hypot(dx,dz),limit=150;if(distance>limit){dx*=limit/distance;dz*=limit/distance;}const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.16));dx/=steps;dz/=steps;let blocked=distance>limit;for(let i=0;i<steps;i++){if(walkable(x+dx,z,radius))x+=dx;else blocked=true;if(walkable(x,z+dz,radius))z+=dz;else blocked=true;}return{x,z,blocked};}
 return Object.freeze({bounds,spawn,obstacles,circles,walkable,move,create});
}
const layout=root.CDFSanctuaryLayout||(typeof require==='function'?require('./sanctuary_layout.js'):null);
if(!layout)throw Error('Sanctuary layout unavailable');const api=create(layout);root.CDFSanctuaryMovement=api;if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof window==='undefined'?globalThis:window);
